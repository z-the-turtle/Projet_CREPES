import matplotlib.pyplot as plt
import matplotlib.patches as patches
import matplotlib.animation as animation
import numpy as np

# Paramètres généraux
sol_width = 100
sol_height = 2
air_height = 10

nb_blocs = 18
bloc_width = sol_width / nb_blocs

vitesse = 1

# Grandeurs physiques
m = 1.0
c = 1000.0
A = 1.0
h = 15.0
dt = 24 * 3600
k = (h * A) / (m * c)

# Température du sol
def sol_temperature(x):
    return 10 if x < sol_width / 2 else 20

# Initialisation
bloc_positions = np.arange(0, sol_width, bloc_width)
bloc_temps = np.array([sol_temperature(x + bloc_width / 2) for x in bloc_positions], dtype=float)

sol_y = 4
y_air = sol_y + sol_height + 0.5

fig, ax = plt.subplots(figsize=(14, 8))
ax.set_xlim(0, sol_width)
ax.set_ylim(0, y_air + air_height + 3)
ax.axis('off')
plt.title("Échange thermique (loi de Newton) — flèches directionnelles", fontsize=18)

# Sol visuel
ax.add_patch(patches.Rectangle((0, sol_y), sol_width / 2, sol_height, facecolor='midnightblue'))
ax.add_patch(patches.Rectangle((sol_width / 2, sol_y), sol_width / 2, sol_height, facecolor='lightcoral'))
ax.text(25, sol_y + 0.5, "Sol nuit 10°C", ha='center', fontsize=14, color='white')
ax.text(75, sol_y + 0.5, "Sol jour 20°C", ha='center', fontsize=14, color='black')

blocs = []
labels = []
arrows = []
power_labels = []

max_arrow_length = 4.0
scaling_factor = 0.08

for i, x in enumerate(bloc_positions):
    temp = bloc_temps[i]
    color_ratio = np.clip((temp - 10) / 10, 0, 1)
    rect = patches.Rectangle((x, y_air), bloc_width, air_height,
                             facecolor=(color_ratio, 0.2, 1 - color_ratio), edgecolor='black')
    ax.add_patch(rect)

    label = ax.text(x + bloc_width / 2, y_air + air_height / 2, f"{temp:.1f}°C",
                    ha='center', va='center', fontsize=12, color='white', weight='bold')

    arrow = ax.arrow(0, 0, 0, 0, head_width=3, head_length=0.6, fc='orange', ec='orange')
    power_label = ax.text(x + bloc_width / 2, sol_y - 1, "",
                          ha='center', va='top', fontsize=12, color='orange')

    blocs.append(rect)
    labels.append(label)
    arrows.append(arrow)
    power_labels.append(power_label)

def update(frame):
    global bloc_positions, bloc_temps

    bloc_positions[:] = (bloc_positions + vitesse) % sol_width

    for i in range(nb_blocs):
        x_center = (bloc_positions[i] + bloc_width / 2) % sol_width
        T_sol = sol_temperature(x_center)
        T_air = bloc_temps[i]
        T_air_next = T_air + k * (T_sol - T_air) * dt
        bloc_temps[i] = T_air_next

        color_ratio = np.clip((T_air_next - 10) / 10, 0, 1)
        color = (color_ratio, 0.2, 1 - color_ratio)
        blocs[i].set_x(bloc_positions[i])
        blocs[i].set_facecolor(color)

        labels[i].set_position((bloc_positions[i] + bloc_width / 2, y_air + air_height / 2))
        labels[i].set_text(f"{T_air_next:.1f}°C")

        P = h * A * (T_sol - T_air)
        arrow_length = np.clip(abs(P) * scaling_factor, 0.3, max_arrow_length)

        arrows[i].remove()

        x_arrow = bloc_positions[i] + bloc_width / 2
        if P > 0:
            y_arrow = sol_y + sol_height
            dy = arrow_length
        else:
            y_arrow = y_air
            dy = -arrow_length

        arrows[i] = ax.arrow(x_arrow, y_arrow, 0, dy,
                             head_width=3, head_length=0.6, fc='orange', ec='orange')

        power_labels[i].set_position((x_arrow, sol_y - 0.5))
        power_labels[i].set_text(f"{P:+.1f} W")

    return blocs + labels + arrows + power_labels

ani = animation.FuncAnimation(fig, update, frames=300, interval=100, blit=True)

n_steps = 1000
def puissance_echange(t_heure):
    dt_sim = t_heure / 20.0
    new_positions = (bloc_positions + vitesse * dt_sim) % sol_width
    temps_air_sim = bloc_temps.copy()

    for i in range(nb_blocs):
        x_center = (new_positions[i] + bloc_width / 2) % sol_width
        T_sol = sol_temperature(x_center)
        T_air = temps_air_sim[i]
        T_air_next = T_air + k * (T_sol - T_air) * dt_sim
        temps_air_sim[i] = T_air_next

    puissances = []
    for i in range(nb_blocs):
        x_center = (new_positions[i] + bloc_width / 2) % sol_width
        T_sol = sol_temperature(x_center)
        T_air = temps_air_sim[i]
        P = h * A * (T_sol - T_air)
        puissances.append(P)

    return sum(puissances)

temps = np.linspace(0, vitesse * dt, n_steps)
puissances = [puissance_echange(t) for t in temps]

plt.figure(figsize=(10, 5))
plt.plot(temps, puissances, color='orange', lw=2)
plt.xlabel("Temps (sec)")
plt.ylabel("Puissance totale échangée (W)")
plt.title("Puissance échangée sol-air sur 24 heures")
plt.grid(True)
plt.tight_layout()
plt.show()
